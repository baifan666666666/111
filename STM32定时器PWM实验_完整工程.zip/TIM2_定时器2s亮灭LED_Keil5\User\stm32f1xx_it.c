/**
 * stm32f1xx_it.c — 中断服务程序（HAL 库）
 * TIM2 定时器实验：TIM2 更新中断里翻转板载 LED(PC13)，实现 2s 周期亮灭。
 */

#include "stm32f1xx_hal.h"

/* ---- TIM 寄存器位定义（本工程未启用 HAL_TIM 模块，故在此定义所需宏） ---- */
#ifndef TIM_SR_UIF
#define TIM_SR_UIF     (0x0001U)   /* 更新中断标志 */
#endif

/* ---- Cortex-M3 内核异常处理 ---- */
void NMI_Handler(void)          { while (1) { } }
void HardFault_Handler(void)    { while (1) { } }
void MemManage_Handler(void)    { while (1) { } }
void BusFault_Handler(void)     { while (1) { } }
void UsageFault_Handler(void)   { while (1) { } }
void SVC_Handler(void)          { }
void DebugMon_Handler(void)     { }
void PendSV_Handler(void)       { }
void SysTick_Handler(void)
{
    HAL_IncTick();              /* HAL 时基 */
}

/* ---- TIM2 更新中断：翻转 PC13 板载 LED ---- */
void TIM2_IRQHandler(void)
{
    if (TIM2->SR & TIM_SR_UIF)          /* 更新标志 */
    {
        TIM2->SR &= ~TIM_SR_UIF;        /* 清标志 */
        HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);   /* 翻转 LED */
    }
}

