/**
 * STM32F103 HAL库 TIM2 定时器计数实验
 * 功能：用 TIM2 定时器计数方式，产生 2s 周期更新中断，在中断里翻转板载 LED(PC13)。
 *       使 LED 以 2s 的频率周期性地亮-灭。
 *
 * 定时器参数：
 *   时钟：内部 HSI 8MHz（APB1 不分频，TIM2 时钟 = 8MHz）
 *   PSC = 7999  →  计数时钟 = 8MHz / 8000 = 1kHz
 *   ARR = 1999  →  更新周期 = 2000 / 1kHz = 2s
 *
 * 引脚：PC13 = 板载 LED（低电平点亮），推挽输出
 * 芯片：STM32F103C8T6，宏：STM32F103xB, USE_HAL_DRIVER
 * 环境：Keil5 (MDK-ARM) + STM32F1xx HAL 库（定时器用寄存器方式配置，无需 HAL_TIM 模块）
 */

#include "stm32f1xx_hal.h"

/* ---- TIM 寄存器位定义（本工程未启用 HAL_TIM 模块，故在此定义所需宏） ---- */
#ifndef TIM_CR1_CEN
#define TIM_CR1_CEN    (0x0001U)   /* 计数器使能 */
#endif
#ifndef TIM_DIER_UIE
#define TIM_DIER_UIE   (0x0001U)   /* 更新中断使能 */
#endif
#ifndef TIM_SR_UIF
#define TIM_SR_UIF     (0x0001U)   /* 更新中断标志 */
#endif

void SystemClock_Config(void);
void MX_GPIO_Init(void);
void MX_TIM2_Init(void);
void Error_Handler(void);

int main(void)
{
    HAL_Init();            /* HAL 初始化（含 SysTick 时基） */
    SystemClock_Config();  /* 配置系统时钟（内部HSI 8MHz） */
    MX_GPIO_Init();        /* 初始化 PC13 为推挽输出 */
    MX_TIM2_Init();        /* 寄存器方式配置 TIM2：2s 更新中断 */

    while (1)
    {
        /* 主循环空转，LED 翻转在 TIM2 更新中断里完成 */
    }
}

/**
 * @brief 系统时钟配置：内部 HSI 8MHz 直接作为 SYSCLK
 */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
                                  RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK) { Error_Handler(); }
}

/**
 * @brief GPIO 初始化：PC13 板载 LED，推挽输出
 */
void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOC_CLK_ENABLE();

    /* PC13 推挽输出，低速 */
    GPIO_InitStruct.Pin = GPIO_PIN_13;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);  /* 初始为高电平，LED 灭 */
}

/**
 * @brief TIM2 寄存器方式初始化：2s 更新周期，开启更新中断
 *        PSC=7999, ARR=1999 → 更新周期 = 8MHz/8000/2000 = 2s
 */
void MX_TIM2_Init(void)
{
    __HAL_RCC_TIM2_CLK_ENABLE();

    TIM2->PSC = 7999;              /* 预分频：8MHz / 8000 = 1kHz */
    TIM2->ARR = 1999;              /* 自动重载：1kHz / 2000 = 0.5Hz = 2s */
    TIM2->CNT = 0;

    /* 使能更新中断 */
    TIM2->DIER |= TIM_DIER_UIE;

    /* 配置 NVIC：TIM2 全局中断 */
    HAL_NVIC_SetPriority(TIM2_IRQn, 1, 0);
    HAL_NVIC_EnableIRQ(TIM2_IRQn);

    /* 启动定时器（先清更新标志再启动） */
    TIM2->SR &= ~TIM_SR_UIF;
    TIM2->CR1 |= TIM_CR1_CEN;
}

/**
 * @brief 错误处理
 */
void Error_Handler(void)
{
    __disable_irq();
    while (1) { }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
    (void)file;
    (void)line;
    while (1) { }
}
#endif
