# STM32F103 定时器与 PWM 呼吸灯实验（HAL库）

基于 STM32F103C8T6 + Keil5 + HAL库 的定时器与 PWM 实验，包含两个工程。

## 工程一：TIM2_定时器2s亮灭LED

- 目录：`TIM2_定时器2s亮灭LED_Keil5`
- 功能：用 TIM2 定时器计数方式产生 2s 更新中断，翻转板载 LED(PC13)，LED 以 2s 周期亮-灭。
- 参数：PSC=7999、ARR=1999 → 更新周期 = 8MHz/8000/2000 = 2s
- 引脚：PC13（板载 LED，低电平点亮）

## 工程二：TIM3_PWM呼吸灯

- 目录：`TIM3_PWM呼吸灯_Keil5`
- 功能：用 TIM3 通道2 输出 1kHz PWM，主循环改变占空比(CCR2 0→999→0)，实现 LED 呼吸灯，周期约 2s。
- 参数：PSC=7、ARR=999 → PWM 频率 = 8MHz/8/1000 = 1kHz；PWM 模式1
- 引脚：PA7 = TIM3_CH2（复用推挽输出），外接 LED（LED+ 接 3.3V，LED- 经限流电阻接 PA7）

## 硬件连接

- 开发板：STM32F103C8T6 最小系统板（板载 LED 接 PC13）
- 呼吸灯 LED：外接至 PA7，需串联 220Ω~330Ω 限流电阻
- 烧录：板载 CH340 或 ST-Link，通过 Keil 烧录

## 编译与烧录

1. 用 Keil uVision5 打开对应工程 `.uvprojx` 文件。
2. 点击 `Project → Rebuild`（F7）编译，0 Error 0 Warning。
3. 点击 `Download`（F8）烧录到开发板。

## Keil 虚拟示波器观察 PWM

1. `Debug → Start/Stop Debug Session`，选软件仿真(Simulator)。
2. `View → Analysis Windows → Logic Analyzer`。
3. `Setup` → 输入 `PORTA.7`（观察 PA7 PWM）。
4. 全速运行，可看到 1kHz 方波，周期约 1ms。

## 开发环境

- Keil uVision5（MDK-ARM）
- STM32CubeMX（可重新生成初始化代码，本工程用寄存器方式配置定时器）
- HAL 库 + CMSIS

## 实验结果

- 任务一：板载 LED 每 2s 翻转一次（亮 1s 灭 1s）。
- 任务二：外接 LED 渐亮渐灭，形成呼吸效果，周期约 2s。
