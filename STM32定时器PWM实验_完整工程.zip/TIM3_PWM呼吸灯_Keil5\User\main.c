/**
 * STM32F103 HAL库 TIM3 PWM 呼吸灯实验
 * 功能：用 TIM3 通道2(CH2) 输出 PWM，外接 LED 到 PA7。
 *       在主循环里循环改变占空比(CCR2)，使 LED 渐亮→渐灭，形成"呼吸灯"效果。
 *       呼吸周期约 2s（渐亮 1s + 渐灭 1s）。
 *
 * PWM 参数：
 *   时钟：内部 HSI 8MHz（APB1 不分频，TIM3 时钟 = 8MHz）
 *   PSC = 7    →  计数时钟 = 8MHz / 8 = 1MHz
 *   ARR = 999  →  PWM 频率 = 1MHz / 1000 = 1kHz
 *   CCR2 = 0~999 占空比 0~100%，PWM 模式1（低电平对齐）
 *
 * 引脚：PA7 = TIM3_CH2（复用推挽输出），外接 LED（LED+接3.3V，LED-经限流电阻接PA7）
 * 芯片：STM32F103C8T6，宏：STM32F103xB, USE_HAL_DRIVER
 * 环境：Keil5 (MDK-ARM) + STM32F1xx HAL 库（定时器用寄存器方式配置，无需 HAL_TIM 模块）
 */

#include "stm32f1xx_hal.h"

/* ---- TIM 寄存器位定义（本工程未启用 HAL_TIM 模块，故在此定义所需宏） ---- */
#ifndef TIM_CR1_CEN
#define TIM_CR1_CEN       (0x0001U)   /* 计数器使能 */
#endif
#ifndef TIM_CR1_ARPE
#define TIM_CR1_ARPE      (0x0080U)   /* 自动重载预装载使能 */
#endif
#ifndef TIM_CCMR1_OC2M_1
#define TIM_CCMR1_OC2M_1  (0x2000U)   /* OC2M bit1：PWM 模式1 组合位 */
#endif
#ifndef TIM_CCMR1_OC2M_2
#define TIM_CCMR1_OC2M_2  (0x4000U)   /* OC2M bit2：PWM 模式1 组合位 */
#endif
#ifndef TIM_CCMR1_OC2PE
#define TIM_CCMR1_OC2PE   (0x0800U)   /* 输出比较2 预装载使能 */
#endif
#ifndef TIM_CCER_CC2E
#define TIM_CCER_CC2E     (0x0100U)   /* 通道2 输出使能 */
#endif

void SystemClock_Config(void);
void MX_GPIO_Init(void);
void MX_TIM3_PWM_Init(void);
void Error_Handler(void);

int main(void)
{
    uint16_t duty = 0;

    HAL_Init();            /* HAL 初始化（含 SysTick 时基） */
    SystemClock_Config();  /* 配置系统时钟（内部HSI 8MHz） */
    MX_GPIO_Init();        /* 初始化 PA7 为 TIM3_CH2 复用推挽输出 */
    MX_TIM3_PWM_Init();    /* 寄存器方式配置 TIM3 CH2 输出 1kHz PWM */

    while (1)
    {
        /* 渐亮：占空比 0% → 100%（CCR 0→999），每步 1ms，约 1s */
        for (duty = 0; duty <= 999; duty++)
        {
            TIM3->CCR2 = duty;
            HAL_Delay(1);
        }
        /* 渐灭：占空比 100% → 0%（CCR 999→0），约 1s */
        for (duty = 999; duty > 0; duty--)
        {
            TIM3->CCR2 = duty;
            HAL_Delay(1);
        }
    }
}

/**
 * @brief 系统时钟配置：内部 HSI 8MHz 直接作为 SYSCLK
 */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
                                  RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK) { Error_Handler(); }
}

/**
 * @brief GPIO 初始化：PA7 配置为 TIM3_CH2 复用推挽输出
 */
void MX_GPIO_Init(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();

    /* PA7 位于 GPIOA 控制寄存器低 16 位(CRL)，Pin7 占用 bit31:28 */
    GPIOA->CRL &= ~(0xFU << 28);       /* 清零 PA7 配置 */
    GPIOA->CRL |= (0xBU << 28);        /* 复用功能推挽输出，50MHz */
}

/**
 * @brief TIM3 寄存器方式初始化：CH2 输出 1kHz PWM，模式1
 *        PSC=7, ARR=999 → PWM 频率 = 8MHz/8/1000 = 1kHz
 */
void MX_TIM3_PWM_Init(void)
{
    __HAL_RCC_TIM3_CLK_ENABLE();

    TIM3->PSC = 7;                     /* 预分频：8MHz / 8 = 1MHz */
    TIM3->ARR = 999;                   /* 自动重载：PWM 频率 = 1MHz / 1000 = 1kHz */
    TIM3->CNT = 0;
    TIM3->CCR2 = 0;                    /* 初始占空比 0% */

    /* CCMR1 的 OC2 配置：PWM 模式1（OC2M=110）+ 输出比较预装载 */
    TIM3->CCMR1 |= TIM_CCMR1_OC2M_1 | TIM_CCMR1_OC2M_2;   /* OC2M = 110 → PWM 模式1 */
    TIM3->CCMR1 |= TIM_CCMR1_OC2PE;                        /* 输出比较预装载使能 */

    /* CCER：使能通道2输出 */
    TIM3->CCER |= TIM_CCER_CC2E;

    /* CR1：自动重载预装载使能 + 启动定时器 */
    TIM3->CR1 |= TIM_CR1_ARPE | TIM_CR1_CEN;
}

/**
 * @brief 错误处理
 */
void Error_Handler(void)
{
    __disable_irq();
    while (1) { }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
    (void)file;
    (void)line;
    while (1) { }
}
#endif
