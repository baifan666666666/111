/**
 * stm32f1xx_hal_msp.c — 外设 MSP（底层初始化）回调
 * 任务一：USART1 串口实验（PA9=TX, PA10=RX）
 *   HAL_UART_MspInit 中完成 USART1 时钟使能与引脚(PA9/PA10 复用推挽)配置
 */

#include "stm32f1xx_hal.h"

void HAL_MspInit(void)
{
    /* 可选：配置 SysTick 等全局底层（此处默认即可） */
}

/**
 * @brief USART 底层初始化：使能时钟 + 配置引脚
 */
void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    if (huart->Instance == USART1)
    {
        __HAL_RCC_USART1_CLK_ENABLE();
        __HAL_RCC_GPIOA_CLK_ENABLE();

        /* PA9 = USART1_TX，PA10 = USART1_RX，复用推挽输出 */
        GPIO_InitStruct.Pin = GPIO_PIN_9 | GPIO_PIN_10;
        GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
    }
}

/**
 * @brief USART 底层反初始化
 */
void HAL_UART_MspDeInit(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1)
    {
        __HAL_RCC_USART1_CLK_DISABLE();
        HAL_GPIO_DeInit(GPIOA, GPIO_PIN_9 | GPIO_PIN_10);
    }
}
