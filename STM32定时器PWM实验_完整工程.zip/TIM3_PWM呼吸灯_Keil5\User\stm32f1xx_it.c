/**
 * stm32f1xx_it.c — 中断服务程序（HAL 库）
 * 任务一：USART1 轮询方式收发，本文件仅保留内核异常与 SysTick 时基，
 *         不涉及外设中断（轮询方式无需 USART1_IRQHandler）。
 */

#include "stm32f1xx_hal.h"

/* ---- Cortex-M3 内核异常处理 ---- */
void NMI_Handler(void)          { while (1) { } }
void HardFault_Handler(void)    { while (1) { } }
void MemManage_Handler(void)    { while (1) { } }
void BusFault_Handler(void)     { while (1) { } }
void UsageFault_Handler(void)   { while (1) { } }
void SVC_Handler(void)          { }
void DebugMon_Handler(void)     { }
void PendSV_Handler(void)       { }
void SysTick_Handler(void)
{
    HAL_IncTick();              /* HAL 时基 */
}
