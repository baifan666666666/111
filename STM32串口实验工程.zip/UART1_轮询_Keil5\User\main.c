/**
 * STM32F103 HAL库 USART1 串口实验（任务一）
 * 功能：
 *   1) STM32 通过 USART1(115200-8-N-1) 连续向上位机发送 "hello windows!"
 *      连续发送之间默认加 100ms 延时；若要去掉延时观察"是否丢数据"，
 *      将下方 SEND_DELAY_MS 改为 0 并重新编译烧录即可。
 *   2) 上位机发送 '#'  → STM32 暂停发送 "hello windows!"
 *      上位机发送 '*'  → STM32 继续发送
 *
 * 引脚：PA9=USART1_TX，PA10=USART1_RX（接 USB转TTL 模块到上位机）
 * 时钟：内部 HSI 8MHz 直接作为 SYSCLK（无需外部晶振）
 * 芯片：STM32F103C8T6，宏：STM32F103xB, USE_HAL_DRIVER
 * 环境：Keil5 (MDK-ARM) + STM32F1xx HAL 库
 */

#include "stm32f1xx_hal.h"
#include <string.h>

/* 发送间隔延时(ms)。测"不加延时是否丢数据"时改为 0 */
#define SEND_DELAY_MS   100

UART_HandleTypeDef huart1;

/* 发送标志：1=发送，0=暂停 */
volatile uint8_t send_flag = 1;

void SystemClock_Config(void);
void MX_GPIO_Init(void);
void MX_USART1_UART_Init(void);
void Error_Handler(void);

int main(void)
{
    const char msg[] = "hello windows!\r\n";
    uint8_t rx_char = 0;

    HAL_Init();            /* HAL 初始化（含 SysTick 时基） */
    SystemClock_Config();  /* 配置系统时钟（内部HSI 8MHz） */
    MX_GPIO_Init();
    MX_USART1_UART_Init(); /* 初始化 USART1：115200-8-N-1 */

    while (1)
    {
        /* ---- 1. 连续发送 hello windows! ---- */
        if (send_flag == 1)
        {
            HAL_UART_Transmit(&huart1, (uint8_t *)msg, strlen(msg), 100);
            HAL_Delay(SEND_DELAY_MS);   /* 改为 0 即"不加延时"，观察丢数据 */
        }

        /* ---- 2. 轮询接收上位机指令：# 暂停，* 继续 ---- */
        if (HAL_UART_Receive(&huart1, &rx_char, 1, 10) == HAL_OK)
        {
            if (rx_char == '#')
            {
                send_flag = 0;   /* 收到 # ：暂停发送 */
            }
            else if (rx_char == '*')
            {
                send_flag = 1;   /* 收到 * ：继续发送 */
            }
        }
    }
}

/**
 * @brief 系统时钟配置：内部 HSI 8MHz 直接作为 SYSCLK
 */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
                                  RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK) { Error_Handler(); }
}

/**
 * @brief GPIO 初始化（本实验 USART 引脚在 MSP 中配置，此处仅作占位）
 */
void MX_GPIO_Init(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();
}

/**
 * @brief USART1 初始化：波特率 115200，8数据位，1停止位，无校验
 */
void MX_USART1_UART_Init(void)
{
    huart1.Instance = USART1;
    huart1.Init.BaudRate = 115200;
    huart1.Init.WordLength = UART_WORDLENGTH_8B;
    huart1.Init.StopBits = UART_STOPBITS_1;
    huart1.Init.Parity = UART_PARITY_NONE;
    huart1.Init.Mode = UART_MODE_TX_RX;
    huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart1) != HAL_OK) { Error_Handler(); }
}

/**
 * @brief 错误处理
 */
void Error_Handler(void)
{
    __disable_irq();
    while (1) { }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
    (void)file;
    (void)line;
    while (1) { }
}
#endif
