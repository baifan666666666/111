/**
 * STM32F103 HAL库 USART1 串口中断接收实验（任务二·1）
 * 功能：用"串口中断接收"重做任务一(2)：
 *   - STM32 通过 USART1(115200-8-N-1) 连续发送 "hello windows!"
 *   - 上位机发 '#' → 中断回调置 send_flag=0，暂停发送
 *   - 上位机发 '*' → 中断回调置 send_flag=1，继续发送
 *   - 接收完全由串口中断完成（HAL_UART_RxCpltCallback），主循环只管发送
 *
 * 引脚：PA9=USART1_TX，PA10=USART1_RX（接 USB转TTL 模块到上位机）
 * 时钟：内部 HSI 8MHz 直接作为 SYSCLK（无需外部晶振）
 * 芯片：STM32F103C8T6，宏：STM32F103xB, USE_HAL_DRIVER
 * 环境：Keil5 (MDK-ARM) + STM32F1xx HAL 库
 */

#include "stm32f1xx_hal.h"
#include <string.h>

UART_HandleTypeDef huart1;

/* 发送标志：1=发送，0=暂停（由串口中断回调修改） */
volatile uint8_t send_flag = 1;

/* 中断接收缓冲 */
volatile uint8_t rx_char = 0;

void SystemClock_Config(void);
void MX_GPIO_Init(void);
void MX_USART1_UART_Init(void);
void Error_Handler(void);

int main(void)
{
    const char msg[] = "hello windows!\r\n";

    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_USART1_UART_Init();

    /* 开启 USART1 中断接收（每次收 1 字节，收到后回调里再重开） */
    if (HAL_UART_Receive_IT(&huart1, (uint8_t *)&rx_char, 1) != HAL_OK)
    {
        Error_Handler();
    }

    while (1)
    {
        /* 连续发送 hello windows!，受 send_flag 控制 */
        if (send_flag == 1)
        {
            HAL_UART_Transmit(&huart1, (uint8_t *)msg, strlen(msg), 100);
            HAL_Delay(100);
        }
    }
}

/**
 * @brief 串口接收完成回调（由中断在收到一字节后调用）
 *        '#'→暂停发送，'*'→继续发送
 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1)
    {
        if (rx_char == '#')
        {
            send_flag = 0;   /* 暂停 */
        }
        else if (rx_char == '*')
        {
            send_flag = 1;   /* 继续 */
        }

        /* 重新开启中断接收，准备接收下一个字符 */
        HAL_UART_Receive_IT(&huart1, (uint8_t *)&rx_char, 1);
    }
}

void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
                                  RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK) { Error_Handler(); }
}

void MX_GPIO_Init(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();
}

void MX_USART1_UART_Init(void)
{
    huart1.Instance = USART1;
    huart1.Init.BaudRate = 115200;
    huart1.Init.WordLength = UART_WORDLENGTH_8B;
    huart1.Init.StopBits = UART_STOPBITS_1;
    huart1.Init.Parity = UART_PARITY_NONE;
    huart1.Init.Mode = UART_MODE_TX_RX;
    huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart1) != HAL_OK) { Error_Handler(); }
}

void Error_Handler(void)
{
    __disable_irq();
    while (1) { }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
    (void)file;
    (void)line;
    while (1) { }
}
#endif
