/**
 * STM32F103 HAL库 USART1 串口 DMA 连续发送实验（任务二·3）
 * 功能：
 *   - USART1(115200-8-N-1) 通过 DMA 向上位机连续发送 "hello windows!"
 *   - 首次用 HAL_UART_Transmit_DMA 启动发送，发送完成回调
 *     HAL_UART_TxCpltCallback 中再次调用，实现"不加 CPU 干预"的连续发送
 *   - 对比任务一：发送过程由 DMA 自动搬运数据，CPU 空闲
 *
 * 引脚：PA9=USART1_TX(→DMA1_CH4)，PA10=USART1_RX
 * 时钟：内部 HSI 8MHz 直接作为 SYSCLK
 * 芯片：STM32F103C8T6，宏：STM32F103xB, USE_HAL_DRIVER
 * 环境：Keil5 (MDK-ARM) + STM32F1xx HAL 库
 */

#include "stm32f1xx_hal.h"
#include <string.h>

UART_HandleTypeDef huart1;
DMA_HandleTypeDef hdma_usart1_tx;

volatile uint8_t send_flag = 1;

void SystemClock_Config(void);
void MX_GPIO_Init(void);
void MX_DMA_Init(void);
void MX_USART1_UART_Init(void);
void Error_Handler(void);

int main(void)
{
    const char msg[] = "hello windows!\r\n";

    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_DMA_Init();
    MX_USART1_UART_Init();   /* 内部通过 MSP 配置 DMA1_CH4 关联 USART1_TX */

    /* 启动第一次 DMA 发送，之后由发送完成回调接力循环 */
    if (HAL_UART_Transmit_DMA(&huart1, (uint8_t *)msg, strlen(msg)) != HAL_OK)
    {
        Error_Handler();
    }

    while (1)
    {
        /* CPU 空闲：DMA 自动完成数据搬运与发送 */
    }
}

/**
 * @brief DMA 发送完成回调：再次启动发送，形成连续发送
 *        （如需暂停发送，将 send_flag 置 0 即可停在下一次循环）
 */
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    static const char msg[] = "hello windows!\r\n";
    if (huart->Instance == USART1)
    {
        if (send_flag == 1)
        {
            HAL_UART_Transmit_DMA(&huart1, (uint8_t *)msg, strlen(msg));
        }
    }
}

void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
                                  RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK) { Error_Handler(); }
}

void MX_GPIO_Init(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();
}

void MX_DMA_Init(void)
{
    __HAL_RCC_DMA1_CLK_ENABLE();
}

void MX_USART1_UART_Init(void)
{
    huart1.Instance = USART1;
    huart1.Init.BaudRate = 115200;
    huart1.Init.WordLength = UART_WORDLENGTH_8B;
    huart1.Init.StopBits = UART_STOPBITS_1;
    huart1.Init.Parity = UART_PARITY_NONE;
    huart1.Init.Mode = UART_MODE_TX_RX;
    huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart1) != HAL_OK) { Error_Handler(); }
}

void Error_Handler(void)
{
    __disable_irq();
    while (1) { }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
    (void)file;
    (void)line;
    while (1) { }
}
#endif
