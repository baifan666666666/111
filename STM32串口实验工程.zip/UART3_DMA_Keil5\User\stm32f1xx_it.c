/**
 * stm32f1xx_it.c — 中断服务程序（HAL 库）
 * 任务二·3：USART1 串口 DMA 发送
 *   DMA1_Channel4_IRQHandler 调用 HAL_DMA_IRQHandler，
 *   发送完成触发 HAL_UART_TxCpltCallback（在 main.c 中实现）
 */

#include "stm32f1xx_hal.h"

extern DMA_HandleTypeDef hdma_usart1_tx;

/* ---- Cortex-M3 内核异常处理 ---- */
void NMI_Handler(void)          { while (1) { } }
void HardFault_Handler(void)    { while (1) { } }
void MemManage_Handler(void)    { while (1) { } }
void BusFault_Handler(void)     { while (1) { } }
void UsageFault_Handler(void)   { while (1) { } }
void SVC_Handler(void)          { }
void DebugMon_Handler(void)     { }
void PendSV_Handler(void)       { }
void SysTick_Handler(void)
{
    HAL_IncTick();              /* HAL 时基 */
}

/* ---- 外设中断处理 ---- */

/**
 * @brief DMA1 通道4 中断：USART1_TX 发送完成
 */
void DMA1_Channel4_IRQHandler(void)
{
    HAL_DMA_IRQHandler(&hdma_usart1_tx);
}
