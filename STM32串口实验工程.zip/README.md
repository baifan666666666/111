# STM32F103 串口通信实验（HAL库）

基于STM32F103C8T6 + Keil5 + HAL库的串口通信实验，包含三种通信方式。

## 实验内容

### 1. UART1 轮询方式
- USART1 (PA9-TX / PA10-RX)，波特率115200
- 连续发送 `hello windows!`
- 上位机发 `#` 暂停，发 `*` 恢复

### 2. UART2 中断方式
- 用串口中断接收，CPU占用更低
- 功能和轮询方式一致

### 3. UART3 DMA方式
- 用DMA1通道4自动发送，CPU完全空闲
- 适合大数据量高速传输

## 硬件连接
- 开发板：STM32F103C8T6最小系统板（板载CH340）
- 接线：PA9(TX) → CH340 RX，PA10(RX) → CH340 TX，GND共地
- 上位机：Windows + 串口助手（sscom / 网页版串口助手）

## 实验结果
- 串口助手连续收到 `hello windows!`
- 发送 `#` 后暂停，发送 `*` 后恢复
- 三种方式均工作正常

## 开发环境
- Keil uVision5
- STM32CubeMX（生成初始化代码）
- HAL库
