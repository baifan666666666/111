/**
 * stm32f1xx_it.c — 中断服务程序（HAL 库）
 * 任务二·1：USART1 串口中断接收
 *   USART1_IRQHandler 调用 HAL_UART_IRQHandler，接收完成触发
 *   HAL_UART_RxCpltCallback（在 main.c 中实现）
 */

#include "stm32f1xx_hal.h"

extern UART_HandleTypeDef huart1;

/* ---- Cortex-M3 内核异常处理 ---- */
void NMI_Handler(void)          { while (1) { } }
void HardFault_Handler(void)    { while (1) { } }
void MemManage_Handler(void)    { while (1) { } }
void BusFault_Handler(void)     { while (1) { } }
void UsageFault_Handler(void)   { while (1) { } }
void SVC_Handler(void)          { }
void DebugMon_Handler(void)     { }
void PendSV_Handler(void)       { }
void SysTick_Handler(void)
{
    HAL_IncTick();              /* HAL 时基 */
}

/* ---- 外设中断处理 ---- */

/**
 * @brief USART1 中断服务函数：串口接收（RXNE）等
 *        调用 HAL 统一入口，接收完成进入 HAL_UART_RxCpltCallback
 */
void USART1_IRQHandler(void)
{
    HAL_UART_IRQHandler(&huart1);
}
