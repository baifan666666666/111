.\startup_stm32f10x_md.o: Drivers\CMSIS\Source\ARM\startup_stm32f10x_md.s
