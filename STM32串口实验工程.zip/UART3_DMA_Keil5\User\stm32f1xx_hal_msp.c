/**
 * stm32f1xx_hal_msp.c — 外设 MSP（底层初始化）回调
 * 任务二·3：USART1 串口 DMA 发送
 *   HAL_UART_MspInit 中完成：
 *     - USART1 时钟 + 引脚(PA9/PA10 复用推挽)
 *     - DMA1 通道4 配置并关联 USART1_TX
 */

#include "stm32f1xx_hal.h"

extern DMA_HandleTypeDef hdma_usart1_tx;

void HAL_MspInit(void)
{
    /* 可选：配置 SysTick 等全局底层（此处默认即可） */
}

/**
 * @brief USART 底层初始化：使能时钟 + 配置引脚 + 配置 DMA
 */
void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    if (huart->Instance == USART1)
    {
        __HAL_RCC_USART1_CLK_ENABLE();
        __HAL_RCC_GPIOA_CLK_ENABLE();
        __HAL_RCC_DMA1_CLK_ENABLE();

        /* PA9 = USART1_TX，PA10 = USART1_RX，复用推挽输出 */
        GPIO_InitStruct.Pin = GPIO_PIN_9 | GPIO_PIN_10;
        GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

        /* DMA1 通道4：存储器→外设(USART1_TX)，字节对齐，普通模式 */
        hdma_usart1_tx.Instance = DMA1_Channel4;
        hdma_usart1_tx.Init.Direction = DMA_MEMORY_TO_PERIPH;
        hdma_usart1_tx.Init.PeriphInc = DMA_PINC_DISABLE;
        hdma_usart1_tx.Init.MemInc = DMA_MINC_ENABLE;
        hdma_usart1_tx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
        hdma_usart1_tx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
        hdma_usart1_tx.Init.Mode = DMA_NORMAL;
        hdma_usart1_tx.Init.Priority = DMA_PRIORITY_LOW;
        if (HAL_DMA_Init(&hdma_usart1_tx) != HAL_OK)
        {
            __disable_irq();
            while (1) { }
        }

        /* 将 DMA 句柄关联到 USART1 */
        __HAL_LINKDMA(huart, hdmatx, hdma_usart1_tx);

        /* DMA1 通道4 中断：发送完成进入 HAL_UART_TxCpltCallback */
        HAL_NVIC_SetPriority(DMA1_Channel4_IRQn, 0, 0);
        HAL_NVIC_EnableIRQ(DMA1_Channel4_IRQn);
    }
}

/**
 * @brief USART 底层反初始化
 */
void HAL_UART_MspDeInit(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1)
    {
        __HAL_RCC_USART1_CLK_DISABLE();
        HAL_GPIO_DeInit(GPIOA, GPIO_PIN_9 | GPIO_PIN_10);
        HAL_DMA_DeInit(huart->hdmatx);
    }
}
