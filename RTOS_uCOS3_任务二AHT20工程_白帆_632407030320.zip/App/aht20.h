/*
 * aht20.h —— AHT20 温湿度传感器驱动（软件 I2C, PB6=SCL, PB7=SDA）
 */
#ifndef AHT20_H
#define AHT20_H

#include "stm32f1xx_hal.h"

uint8_t AHT20_Init(void);
uint8_t AHT20_Read(float *temp, float *humi);

#endif
