/*
 * aht20.c —— AHT20 温湿度传感器驱动（软件 I2C, PB6=SCL, PB7=SDA）
 * 数据手册：测量命令 0xAC，读回 7 字节；湿度/温度各 20 bit
 */
#include "aht20.h"

/* AHT20 7位地址 0x38，写=0x70，读=0x71 */
#define AHT20_ADDR_W   0x70u
#define AHT20_ADDR_R   0x71u

#define SCL_H()  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET)
#define SCL_L()  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET)
#define SDA_H()  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET)
#define SDA_L()  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET)
#define SDA_READ()  HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_7)

/* 短延时（软件 I2C ~100kHz，半周期约5us） */
static void I2C_Delay(void)
{
    uint8_t i;
    for (i = 0; i < 5; i++) { __NOP(); }
}

static void I2C_Start(void)
{
    SDA_H(); SCL_H(); I2C_Delay();
    SDA_L(); I2C_Delay();          /* SCL高时SDA下降沿 = 起始 */
    SCL_L(); I2C_Delay();
}

static void I2C_Stop(void)
{
    SDA_L(); SCL_H(); I2C_Delay();
    SDA_H(); I2C_Delay();          /* SCL高时SDA上升沿 = 停止 */
}

/* 主机发送一个字节，返回从机ACK(0)/NACK(1) */
static uint8_t I2C_WriteByte(uint8_t dat)
{
    uint8_t i, ack;
    for (i = 0; i < 8; i++)
    {
        if (dat & 0x80u) { SDA_H(); } else { SDA_L(); }
        I2C_Delay();
        SCL_H(); I2C_Delay();
        SCL_L(); I2C_Delay();
        dat <<= 1;
    }
    SDA_H();                       /* 释放SDA，等从机ACK */
    I2C_Delay();
    SCL_H(); I2C_Delay();
    ack = (SDA_READ() != GPIO_PIN_RESET) ? 1u : 0u;
    SCL_L(); I2C_Delay();
    return ack;
}

/* 主机读一个字节，ack=1回ACK，ack=0回NACK */
static uint8_t I2C_ReadByte(uint8_t ack)
{
    uint8_t i, dat = 0;
    SDA_H();                       /* 释放SDA为输入 */
    for (i = 0; i < 8; i++)
    {
        dat <<= 1;
        SCL_H(); I2C_Delay();
        if (SDA_READ() != GPIO_PIN_RESET) { dat |= 0x01u; }
        SCL_L(); I2C_Delay();
    }
    if (ack) { SDA_L(); } else { SDA_H(); }   /* ACK/NACK */
    I2C_Delay();
    SCL_H(); I2C_Delay();
    SCL_L(); I2C_Delay();
    SDA_H();
    return dat;
}

/* 读状态字（1字节），bit[3]=1 表示已校准
 * 注：AHT20 无独立读状态命令，初始化采用无条件配置，本函数不再使用 */

uint8_t AHT20_Init(void)
{
    HAL_Delay(40);                 /* 上电稳定 ≥40ms */

    /* 无条件发初始化命令: 0xBE 0x08 0x00（AHT20 允许重复初始化） */
    I2C_Start();
    if (I2C_WriteByte(AHT20_ADDR_W)) { I2C_Stop(); return 1u; }
    I2C_WriteByte(0xBEu);
    I2C_WriteByte(0x08u);
    I2C_WriteByte(0x00u);
    I2C_Stop();
    HAL_Delay(10);
    return 0u;
}

uint8_t AHT20_Read(float *temp, float *humi)
{
    uint8_t buf[7];
    uint32_t hum_raw, tem_raw;
    uint8_t i;

    /* 触发测量: 0xAC 0x33 0x00 */
    I2C_Start();
    if (I2C_WriteByte(AHT20_ADDR_W)) { I2C_Stop(); return 1u; }
    I2C_WriteByte(0xACu);
    I2C_WriteByte(0x33u);
    I2C_WriteByte(0x00u);
    I2C_Stop();

    HAL_Delay(80);                 /* 测量转换 ≈75ms */

    /* 读7字节 */
    I2C_Start();
    if (I2C_WriteByte(AHT20_ADDR_R)) { I2C_Stop(); return 2u; }
    for (i = 0; i < 6; i++) { buf[i] = I2C_ReadByte(1u); }   /* 前6字节回ACK */
    buf[6] = I2C_ReadByte(0u);                               /* 最后1字节回NACK */
    I2C_Stop();

    if (buf[0] & 0x80u) { return 3u; }                      /* bit7=1 忙 */

    hum_raw = ((uint32_t)buf[1] << 12) | ((uint32_t)buf[2] << 4) | (buf[3] >> 4);
    tem_raw = ((uint32_t)(buf[3] & 0x0Fu) << 16) | ((uint32_t)buf[4] << 8) | buf[5];

    *humi = (float)hum_raw * 100.0f / 1048576.0f;           /* /2^20, %RH */
    *temp = (float)tem_raw * 200.0f / 1048576.0f - 50.0f;    /* ℃ */
    return 0u;
}
