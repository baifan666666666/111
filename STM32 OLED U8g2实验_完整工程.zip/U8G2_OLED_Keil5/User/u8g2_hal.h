/**
 * u8g2_hal.h - U8g2 底层移植层接口
 */
#ifndef __U8G2_HAL_H
#define __U8G2_HAL_H

#include "u8g2.h"

/* U8g2 GPIO + 延时回调（软件 I2C：SCL=PB6, SDA=PB7），实现在 u8g2_hal.c */
uint8_t u8x8_gpio_and_delay(u8x8_t *u8x8, uint8_t msg, uint8_t arg_int, void *arg_ptr);

#endif /* __U8G2_HAL_H */
