/**
 * u8g2_hal.c - U8g2 底层移植层（软件 I2C）
 * SCL = PB6, SDA = PB7，GPIO 推挽输出
 * 提供 u8x8_gpio_and_delay 回调，供 u8x8_byte_sw_i2c 驱动时序
 */
#include "stm32f1xx_hal.h"
#include "u8g2.h"

#define I2C_PORT   GPIOB
#define I2C_SCL    GPIO_PIN_6
#define I2C_SDA    GPIO_PIN_7

/* ~微秒级软件延时（HSI 8MHz，volatile 防止被优化） */
static void delay_us(uint32_t us)
{
    volatile uint32_t n = us * 2u;   /* 每循环约 0.5us（8MHz） */
    while (n--) { __NOP(); }
}

/* U8g2 GPIO + 延时回调：只写不读（ACK 不检测，纯推挽软件 I2C） */
uint8_t u8x8_gpio_and_delay(u8x8_t *u8x8, uint8_t msg, uint8_t arg_int, void *arg_ptr)
{
    (void)u8x8; (void)arg_ptr;
    switch (msg)
    {
    case U8X8_MSG_GPIO_AND_DELAY_INIT:
        /* GPIO 已在 U8g2_Init() 中初始化 */
        break;
    case U8X8_MSG_GPIO_I2C_CLOCK:          /* SCL 电平 */
        HAL_GPIO_WritePin(I2C_PORT, I2C_SCL, arg_int ? GPIO_PIN_SET : GPIO_PIN_RESET);
        break;
    case U8X8_MSG_GPIO_I2C_DATA:           /* SDA 电平 */
        HAL_GPIO_WritePin(I2C_PORT, I2C_SDA, arg_int ? GPIO_PIN_SET : GPIO_PIN_RESET);
        break;
    case U8X8_MSG_DELAY_MILLI:
        HAL_Delay(arg_int);
        break;
    case U8X8_MSG_DELAY_10MICRO:
        delay_us((uint32_t)arg_int * 10u);
        break;
    case U8X8_MSG_DELAY_100NANO:
    case U8X8_MSG_DELAY_NANO:
        __NOP();
        break;
    case U8X8_MSG_DELAY_I2C:               /* I2C 半时钟周期：~400kHz（约 1.2us） */
        delay_us(1);
        break;
    default:
        return 0;
    }
    return 1;
}
