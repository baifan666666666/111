﻿/**
 * STM32F103C8 + 0.96" SSD1306 I2C OLED + U8g2 移植（实验任务3）
 *
 * 工程框架：CubeMX 生成的 HAL 库程序框架（等价：main.c + stm32f1xx_hal_msp.c + stm32f1xx_it.c）
 * U8g2：官方源码裁剪移植（仅保留 ssd1306_128x64_noname 驱动与 3 个 ASCII 字体）
 * 软件 I2C：SCL=PB6, SDA=PB7，从机地址 0x78
 *
 * 显示内容：
 *   1) U8g2 demo 例程（文本 + 图形 + 动画）
 *   2) 学号 + 姓名（白帆，16x16 位图 DrawXBM 显示）
 *   3) 左右滑动、上下滑动显示
 *   4) 头像图案（笑脸）+ 眨眼动态效果
 */
#include "stm32f1xx_hal.h"
#include "u8g2.h"
#include "u8g2_hal.h"
#include <string.h>
#include <stdio.h>

u8g2_t u8g2;

/* ---- 姓名"白帆" 24x24 位图（LSB-first，适配 u8g2_DrawXBM） ---- */
static const unsigned char XBM_BAI[72] = {
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0E,0x00,0x00,0x06,0x00,0x00,0x02,0x00,0xF0,0xFF,0x1F,0xF0,0xFF,0x1F,0x30,0x00,0x18,0x30,0x00,0x18,0x30,0x00,0x18,0x30,0x00,0x18,0x30,0x00,0x18,0xF0,0xFF,0x1F,0xF0,0xFF,0x1F,0x30,0x00,0x18,0x30,0x00,0x18,0x30,0x00,0x18,0x30,0x00,0x18,0x30,0x00,0x18,0xF0,0xFF,0x1F,0xF0,0xFF,0x1F,0x30,0x00,0x18,0x30,0x00,0x18,0x00,0x00,0x00
};
static const unsigned char XBM_FAN[72] = {
    0x00,0x00,0x00,0x60,0x00,0x00,0x60,0xF0,0x0F,0x60,0xF0,0x0F,0x60,0x30,0x0C,0xFC,0x37,0x0C,0x64,0x36,0x0C,0x64,0xB6,0x0D,0x64,0xB6,0x0D,0x64,0xB6,0x0D,0x64,0xB6,0x0D,0x64,0xB6,0x0D,0x64,0x36,0x0D,0x64,0x36,0x0D,0x64,0x36,0x0C,0x64,0x16,0x0C,0xE4,0x1B,0x0C,0x64,0x1B,0x2C,0x60,0x0C,0x6C,0x60,0x0C,0x6C,0x60,0x06,0x7C,0x60,0x06,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};

void Error_Handler(void);
void SystemClock_Config(void);

static void U8g2_Init(void);
static void Demo_Graphics(void);
static void Show_Info(void);
static void Scroll_LeftRight(void);
static void Scroll_UpDown(void);
static void Show_Face(void);

int main(void)
{
    HAL_Init();
    SystemClock_Config();
    U8g2_Init();

    while (1)
    {
        Show_Info();        /* 2) 学号 + 姓名 */
        Demo_Graphics();    /* 1) U8g2 demo 例程 */
        Scroll_LeftRight(); /* 3) 左右滑动 */
        Scroll_UpDown();    /* 3) 上下滑动 */
        Show_Face();        /* 4) 笑脸眨眼动态 */
    }
}

/* 4) 头像图案（笑脸）+ 眨眼动态 */
static void Show_Face(void)
{
    uint8_t k;

    for (k = 0; k < 4; k++)
    {
        /* 睁眼：眼睛为空心圆圈 */
        u8g2_ClearBuffer(&u8g2);
        u8g2_DrawCircle(&u8g2, 64, 32, 26, U8G2_DRAW_ALL);   /* 脸 */
        u8g2_DrawCircle(&u8g2, 54, 26, 4, U8G2_DRAW_ALL);    /* 左眼：圆圈 */
        u8g2_DrawCircle(&u8g2, 74, 26, 4, U8G2_DRAW_ALL);    /* 右眼：圆圈 */
        u8g2_DrawLine(&u8g2, 54, 46, 74, 46);                /* 嘴基线 */
        u8g2_DrawLine(&u8g2, 54, 46, 59, 40);                /* 左嘴角 */
        u8g2_DrawLine(&u8g2, 74, 46, 69, 40);                /* 右嘴角 */
        u8g2_SetFont(&u8g2, u8g2_font_6x12_tr);
        u8g2_DrawStr(&u8g2, 54, 60, "Hi!");
        u8g2_SendBuffer(&u8g2);
        HAL_Delay(300);

        /* 眨眼（闭眼）：重绘整帧，圆圈消失只剩横线 */
        u8g2_ClearBuffer(&u8g2);
        u8g2_DrawCircle(&u8g2, 64, 32, 26, U8G2_DRAW_ALL);   /* 脸 */
        u8g2_DrawLine(&u8g2, 48, 26, 60, 26);                /* 左眼横线 */
        u8g2_DrawLine(&u8g2, 68, 26, 80, 26);                /* 右眼横线 */
        u8g2_DrawLine(&u8g2, 54, 46, 74, 46);                /* 嘴基线 */
        u8g2_DrawLine(&u8g2, 54, 46, 59, 40);                /* 左嘴角 */
        u8g2_DrawLine(&u8g2, 74, 46, 69, 40);                /* 右嘴角 */
        u8g2_SetFont(&u8g2, u8g2_font_6x12_tr);
        u8g2_DrawStr(&u8g2, 54, 60, "Hi!");
        u8g2_SendBuffer(&u8g2);
        HAL_Delay(120);
    }
    HAL_Delay(300);
}

/* HSI 8MHz 内部时钟（CubeMX 等价配置） */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK) { Error_Handler(); }
}

/* U8g2 初始化：GPIO + SSD1306 驱动 */
static void U8g2_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOB_CLK_ENABLE();

    /* PB6=SCL, PB7=SDA 推挽输出 */
    GPIO_InitStruct.Pin = GPIO_PIN_6 | GPIO_PIN_7;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6 | GPIO_PIN_7, GPIO_PIN_SET);

    /* U8g2：SSD1306 128x64 I2C full buffer */
    u8g2_Setup_ssd1306_i2c_128x64_noname_f(&u8g2, U8G2_R0, u8x8_byte_sw_i2c, u8x8_gpio_and_delay);
    u8g2_InitDisplay(&u8g2);
    u8g2_SetPowerSave(&u8g2, 0);
    u8g2_ClearBuffer(&u8g2);
    u8g2_SendBuffer(&u8g2);
}

/* 1) U8g2 demo 例程：文本 + 图形 + 动画 */
static void Demo_Graphics(void)
{
    uint8_t k;

    /* 文本 demo */
    u8g2_ClearBuffer(&u8g2);
    u8g2_SetFont(&u8g2, u8g2_font_ncenB10_tr);
    u8g2_DrawStr(&u8g2, 8, 18, "U8g2 Demo");
    u8g2_SetFont(&u8g2, u8g2_font_6x12_tr);
    u8g2_DrawStr(&u8g2, 8, 36, "STM32F103C8T6");
    u8g2_DrawStr(&u8g2, 8, 52, "SSD1306 128x64");
    u8g2_SendBuffer(&u8g2);
    HAL_Delay(800);

    /* 图形 demo：框 / 圆 / 圆点 / 线 */
    u8g2_ClearBuffer(&u8g2);
    u8g2_DrawFrame(&u8g2, 0, 0, 128, 64);
    u8g2_DrawCircle(&u8g2, 34, 32, 22, U8G2_DRAW_ALL);
    u8g2_DrawDisc(&u8g2, 88, 32, 16, U8G2_DRAW_ALL);
    u8g2_DrawLine(&u8g2, 0, 0, 127, 63);
    u8g2_DrawLine(&u8g2, 0, 63, 127, 0);
    u8g2_SendBuffer(&u8g2);
    HAL_Delay(800);

    /* 动画 demo：圆点从左向右跑 */
    for (k = 0; k < 16; k++)
    {
        u8g2_ClearBuffer(&u8g2);
        u8g2_DrawFrame(&u8g2, 0, 0, 127, 63);
        u8g2_DrawDisc(&u8g2, 6 + k * 3, 32, 4, U8G2_DRAW_ALL);
        u8g2_SendBuffer(&u8g2);
        HAL_Delay(8);
    }
    HAL_Delay(300);
}

/* 2) 学号 + 姓名（白帆 16x16 位图） */
static void Show_Info(void)
{
    u8g2_ClearBuffer(&u8g2);

    /* 白帆 24x24 大字居中 */
    u8g2_DrawXBM(&u8g2, 40, 6, 24, 24, XBM_BAI);
    u8g2_DrawXBM(&u8g2, 66, 6, 24, 24, XBM_FAN);

    /* 学号 */
    u8g2_SetFont(&u8g2, u8g2_font_6x12_tr);
    u8g2_DrawStr(&u8g2, 14, 52, "ID:632407030320");

    u8g2_DrawFrame(&u8g2, 0, 0, 127, 63);
    u8g2_SendBuffer(&u8g2);
    HAL_Delay(4000);
}

/* 3) 左右滑动显示 */
static void Scroll_LeftRight(void)
{
    const char *s = "Hello U8g2! Welcome to CQJTU-205 Lab";
    int len = u8g2_GetStrWidth(&u8g2, s);
    int x;

    u8g2_SetFont(&u8g2, u8g2_font_ncenB10_tr);
    /* 从右向左 */
    for (x = 128; x > -len; x -= 20)
    {
        u8g2_ClearBuffer(&u8g2);
        u8g2_DrawStr(&u8g2, x, 32, s);
        u8g2_SendBuffer(&u8g2);
        HAL_Delay(2);
    }
    /* 从左向右 */
    for (x = -len; x < 128; x += 20)
    {
        u8g2_ClearBuffer(&u8g2);
        u8g2_DrawStr(&u8g2, x, 32, s);
        u8g2_SendBuffer(&u8g2);
        HAL_Delay(2);
    }
    HAL_Delay(300);
}

/* 3) 上下滑动显示 */
static void Scroll_UpDown(void)
{
    const char *up   = "Scroll Up";
    const char *down = "Scroll Down";
    int y;

    u8g2_SetFont(&u8g2, u8g2_font_ncenB10_tr);
    /* 文本从下向上移动 */
    for (y = 90; y > 20; y -= 20)
    {
        u8g2_ClearBuffer(&u8g2);
        u8g2_DrawStr(&u8g2, 16, y, up);
        u8g2_DrawStr(&u8g2, 16, y + 16, down);
        u8g2_SendBuffer(&u8g2);
        HAL_Delay(2);
    }
    /* 文本从上向下移动 */
    for (y = 20; y < 90; y += 20)
    {
        u8g2_ClearBuffer(&u8g2);
        u8g2_DrawStr(&u8g2, 16, y, up);
        u8g2_DrawStr(&u8g2, 16, y + 16, down);
        u8g2_SendBuffer(&u8g2);
        HAL_Delay(2);
    }
    HAL_Delay(300);
}

void Error_Handler(void)
{
    __disable_irq();
    while (1) { }
}
