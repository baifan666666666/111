/**
 * 实验4 - RTOS 多任务与温度采集
 * uC/OS-III @ STM32F103C8T6, HAL 库, HSI 8MHz
 *
 * Task1 : 1s 周期翻转 LED1 (PA0, 外接, 高电平亮)
 * Task2 : 3s 周期翻转 LED2 (PB0, 外接, 高电平亮)
 * Task3 : 每 2s 周期通过串口发送 "hello uc/OS! 欢迎来到RTOS多任务环境！"
 *         (USART1 115200)
 */
#include "stm32f1xx_hal.h"
#include "os.h"
#include "app_cfg.h"
#include <stdio.h>

UART_HandleTypeDef huart1;

/* ---------- uC/OS 任务相关 ---------- */
static OS_TCB  Task1_TCB;
static OS_TCB  Task2_TCB;
static OS_TCB  Task3_TCB;
static CPU_STK Task1_Stk[APP_CFG_TASK1_STK_SIZE];
static CPU_STK Task2_Stk[APP_CFG_TASK2_STK_SIZE];
static CPU_STK Task3_Stk[APP_CFG_TASK3_STK_SIZE];

static void AppTask1(void *p_arg);   /* 1s LED1 */
static void AppTask2(void *p_arg);   /* 3s LED2 */
static void AppTask3(void *p_arg);   /* 2s 串口 + AHT20 */

void SystemClock_Config(void);
void Error_Handler(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);

/* ==================================================================
 *                              main
 * ================================================================== */
int main(void)
{
    OS_ERR  err;

    HAL_Init();
    SystemClock_Config();

    MX_GPIO_Init();
    MX_USART1_UART_Init();

    OSInit(&err);                       /* 初始化 uC/OS-III */
    if (err != OS_ERR_NONE) { Error_Handler(); }

    OS_CPU_SysTickInitFreq(8000000u);   /* 配置 SysTick 为 uC/OS tick（8MHz / 1000Hz） */

    OSTaskCreate((OS_TCB     *)&Task1_TCB,
                 (CPU_CHAR   *)"App Task1",
                 (OS_TASK_PTR )AppTask1,
                 (void       *)0,
                 (OS_PRIO     )APP_CFG_TASK1_PRIO,
                 (CPU_STK    *)&Task1_Stk[0],
                 (CPU_STK_SIZE )(APP_CFG_TASK1_STK_SIZE / 10u),
                 (CPU_STK_SIZE )APP_CFG_TASK1_STK_SIZE,
                 (OS_TICK      )0,
                 (OS_MSG_QTY   )0,
                 (void       *)0,
                 (OS_OPT       )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 (OS_ERR     *)&err);
    if (err != OS_ERR_NONE) { Error_Handler(); }

    OSTaskCreate((OS_TCB     *)&Task2_TCB,
                 (CPU_CHAR   *)"App Task2",
                 (OS_TASK_PTR )AppTask2,
                 (void       *)0,
                 (OS_PRIO     )APP_CFG_TASK2_PRIO,
                 (CPU_STK    *)&Task2_Stk[0],
                 (CPU_STK_SIZE )(APP_CFG_TASK2_STK_SIZE / 10u),
                 (CPU_STK_SIZE )APP_CFG_TASK2_STK_SIZE,
                 (OS_TICK      )0,
                 (OS_MSG_QTY   )0,
                 (void       *)0,
                 (OS_OPT       )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 (OS_ERR     *)&err);
    if (err != OS_ERR_NONE) { Error_Handler(); }

    OSTaskCreate((OS_TCB     *)&Task3_TCB,
                 (CPU_CHAR   *)"App Task3",
                 (OS_TASK_PTR )AppTask3,
                 (void       *)0,
                 (OS_PRIO     )APP_CFG_TASK3_PRIO,
                 (CPU_STK    *)&Task3_Stk[0],
                 (CPU_STK_SIZE )(APP_CFG_TASK3_STK_SIZE / 10u),
                 (CPU_STK_SIZE )APP_CFG_TASK3_STK_SIZE,
                 (OS_TICK      )0,
                 (OS_MSG_QTY   )0,
                 (void       *)0,
                 (OS_OPT       )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 (OS_ERR     *)&err);
    if (err != OS_ERR_NONE) { Error_Handler(); }

    OSStart(&err);                      /* 启动多任务调度，不再返回 */

    while (1) { }
}

/* ==================================================================
 *                         任务1: 1s 翻转 LED1
 * ================================================================== */
static void AppTask1(void *p_arg)
{
    OS_ERR err;
    (void)p_arg;
    for (;;)
    {
        HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_0);          /* PA0 外接LED1 */
        OSTimeDlyHMSM(0u, 0u, 1u, 0u, OS_OPT_TIME_HMSM_STRICT, &err);  /* 1s */
    }
}

/* ==================================================================
 *                         任务2: 3s 翻转 LED2
 * ================================================================== */
static void AppTask2(void *p_arg)
{
    OS_ERR err;
    (void)p_arg;
    for (;;)
    {
        HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_0);          /* PB0 外接LED */
        OSTimeDlyHMSM(0u, 0u, 3u, 0u, OS_OPT_TIME_HMSM_STRICT, &err);  /* 3s */
    }
}

/* ==================================================================
 *         任务3: 每 2s 通过串口发送 hello 欢迎信息
 * ================================================================== */
static void AppTask3(void *p_arg)
{
    OS_ERR err;
    uint8_t msg[] = "hello uc/OS! 欢迎来到RTOS多任务环境！\r\n";
    (void)p_arg;

    for (;;)
    {
        HAL_UART_Transmit(&huart1, msg, sizeof(msg) - 1u, 200);       /* 串口发送 */
        OSTimeDlyHMSM(0u, 0u, 2u, 0u, OS_OPT_TIME_HMSM_STRICT, &err); /* 2s */
    }
}

/* ==================================================================
 *                       外设初始化
 * ================================================================== */
/* HSI 8MHz 内部时钟 */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK) { Error_Handler(); }
}

/* PA0=LED1, PB0=LED2 */
static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_RESET);   /* LED1 灭 */
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);   /* LED2 灭 */

    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;

    GPIO_InitStruct.Pin   = GPIO_PIN_0;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_InitStruct.Pin   = GPIO_PIN_0;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

/* USART1: PA9=TX, PA10=RX, 115200 8N1 */
static void MX_USART1_UART_Init(void)
{
    huart1.Instance        = USART1;
    huart1.Init.BaudRate   = 115200;
    huart1.Init.WordLength = UART_WORDLENGTH_8B;
    huart1.Init.StopBits   = UART_STOPBITS_1;
    huart1.Init.Parity     = UART_PARITY_NONE;
    huart1.Init.Mode       = UART_MODE_TX_RX;
    huart1.Init.HwFlowCtl  = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart1) != HAL_OK) { Error_Handler(); }
}

void Error_Handler(void)
{
    __disable_irq();
    while (1) { }
}
