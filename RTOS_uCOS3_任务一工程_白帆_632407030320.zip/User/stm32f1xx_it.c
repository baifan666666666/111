/*
 * stm32f1xx_it.c —— 中断服务函数
 * PendSV / SysTick 交给 uC/OS-III
 */
#include "stm32f1xx_hal.h"
#include "os.h"

void NMI_Handler(void) { }

void HardFault_Handler(void) { while (1) { } }

void MemManage_Handler(void) { while (1) { } }

void BusFault_Handler(void) { while (1) { } }

void UsageFault_Handler(void) { while (1) { } }

void SVC_Handler(void) { }

void DebugMon_Handler(void) { }

/* PendSV 上下文切换（汇编实现） */
void PendSV_Handler(void)
{
    OS_CPU_PendSVHandler();
}

/* SysTick: 既喂 HAL（HAL_Delay 用），又作为 uC/OS 的 tick */
void SysTick_Handler(void)
{
    HAL_IncTick();
    OS_CPU_SysTickHandler();
}
