/*
 * app_cfg.h —— 应用层配置：任务优先级、栈大小
 */
#ifndef APP_CFG_H
#define APP_CFG_H

/* 任务优先级（0 最高，idle 固定为 OS_CFG_PRIO_MAX-1 = 7） */
#define  APP_CFG_TASK1_PRIO              2u    /* Task1: 1s 翻转 LED1 (PC13)   */
#define  APP_CFG_TASK2_PRIO              3u    /* Task2: 3s 翻转 LED2 (PB0)    */
#define  APP_CFG_TASK3_PRIO              4u    /* Task3: 2s 串口 + AHT20 采集   */

/* 任务栈大小（CPU_STK = 4 字节） */
#define  APP_CFG_TASK1_STK_SIZE         128u
#define  APP_CFG_TASK2_STK_SIZE         128u
#define  APP_CFG_TASK3_STK_SIZE         256u   /* 串口 printf + I2C 缓冲，给大一点 */

#endif
