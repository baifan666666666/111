/*
 * uC/OS-III 配置（精简版，适配 STM32F103C8T6 64KB Flash / 20KB RAM）
 * 仅保留任务调度 + 时间延时，关闭信号量/队列/标志/互斥/定时器/统计任务
 */
#ifndef OS_CFG_H
#define OS_CFG_H

                                                                /* --------------------------- MISCELLANEOUS --------------------------- */
#define OS_CFG_APP_HOOKS_EN                        0u           /* 关闭应用钩子                                                          */
#define OS_CFG_ARG_CHK_EN                          0u           /* 关闭参数检查                                                          */
#define OS_CFG_CALLED_FROM_ISR_CHK_EN              0u           /* 关闭 ISR 检查                                                         */
#define OS_CFG_DBG_EN                              0u           /* 关闭调试代码                                                          */
#define OS_CFG_TICK_EN                             1u           /* 使能内核 Tick                                                         */
#define OS_CFG_DYN_TICK_EN                         0u
#define OS_CFG_INVALID_OS_CALLS_CHK_EN             0u
#define OS_CFG_OBJ_TYPE_CHK_EN                     0u
#define OS_CFG_OBJ_CREATED_CHK_EN                  0u
#define OS_CFG_TS_EN                               0u

#define OS_CFG_PRIO_MAX                            8u           /* 最多 8 个优先级（idle=7）                                            */

#define OS_CFG_SCHED_LOCK_TIME_MEAS_EN             0u
#define OS_CFG_SCHED_ROUND_ROBIN_EN                0u           /* 关闭时间片轮转                                                        */
#define OS_CFG_STK_SIZE_MIN                       64u

                                                                /* --------------------------- EVENT FLAGS ----------------------------- */
#define OS_CFG_FLAG_EN                             0u
#define OS_CFG_FLAG_DEL_EN                         0u
#define OS_CFG_FLAG_MODE_CLR_EN                    0u
#define OS_CFG_FLAG_PEND_ABORT_EN                  0u

                                                                /* ------------------------ MEMORY MANAGEMENT -------------------------  */
#define OS_CFG_MEM_EN                              0u

                                                                /* ------------------- MUTUAL EXCLUSION SEMAPHORES --------------------  */
#define OS_CFG_MUTEX_EN                            0u
#define OS_CFG_MUTEX_DEL_EN                        0u
#define OS_CFG_MUTEX_PEND_ABORT_EN                 0u

                                                                /* -------------------------- MESSAGE QUEUES --------------------------  */
#define OS_CFG_Q_EN                                0u
#define OS_CFG_Q_DEL_EN                            0u
#define OS_CFG_Q_FLUSH_EN                          0u
#define OS_CFG_Q_PEND_ABORT_EN                     0u

                                                                /* ---------------------------- SEMAPHORES -----------------------------  */
#define OS_CFG_SEM_EN                              0u
#define OS_CFG_SEM_DEL_EN                          0u
#define OS_CFG_SEM_PEND_ABORT_EN                   0u
#define OS_CFG_SEM_SET_EN                          0u

                                                                /* -------------------------- TASK MANAGEMENT --------------------------  */
#define OS_CFG_STAT_TASK_EN                        0u           /* 关闭统计任务（省栈/CPU）                                            */
#define OS_CFG_STAT_TASK_STK_CHK_EN                0u

#define OS_CFG_TASK_CHANGE_PRIO_EN                 0u
#define OS_CFG_TASK_DEL_EN                         0u
#define OS_CFG_TASK_IDLE_EN                        1u
#define OS_CFG_TASK_PROFILE_EN                     0u
#define OS_CFG_TASK_Q_EN                           0u
#define OS_CFG_TASK_Q_PEND_ABORT_EN                 0u
#define OS_CFG_TASK_REG_TBL_SIZE                    1u

#define OS_CFG_TASK_STK_REDZONE_EN                 0u
#define OS_CFG_TASK_STK_REDZONE_DEPTH              8u

#define OS_CFG_TASK_SEM_PEND_ABORT_EN              0u
#define OS_CFG_TASK_SUSPEND_EN                     0u

                                                                /* ------------------ TASK LOCAL STORAGE MANAGEMENT -------------------  */
#define OS_CFG_TLS_TBL_SIZE                         0u

                                                                /* ------------------------- TIME MANAGEMENT --------------------------  */
#define OS_CFG_TIME_DLY_HMSM_EN                     1u           /* 需要 OSTimeDlyHMSM()                                                  */
#define OS_CFG_TIME_DLY_RESUME_EN                   0u

                                                                /* ------------------------- TIMER MANAGEMENT --------------------------  */
#define OS_CFG_TMR_EN                              0u           /* 关闭定时器任务                                                        */
#define OS_CFG_TMR_DEL_EN                          0u

                                                                /* ------------------------- TRACE RECORDER ---------------------------- */
#define OS_CFG_TRACE_EN                            0u
#define OS_CFG_TRACE_API_ENTER_EN                  0u
#define OS_CFG_TRACE_API_EXIT_EN                   0u

#endif
